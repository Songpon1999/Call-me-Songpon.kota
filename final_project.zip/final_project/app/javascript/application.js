// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"

// Like functionality with toggle state
function likePost(button) {
    var likeCountSpan = button.nextElementSibling;
    var likeCount = parseInt(likeCountSpan.textContent);
    likeCount = (likeCount === 0) ? 1 : 0;
    likeCountSpan.textContent = likeCount;
    // Change like icon color when liked
    if (likeCount === 1) {
      button.style.backgroundColor = '#2d8a1b'; // Darker green
    } else {
      button.style.backgroundColor = '#42b72a'; // Default green
    }
  }

  // Function to edit a post
function editPost(button) {
    var postDiv = button.closest('.post'); // Find the closest post div
    var postContent = postDiv.querySelector('.post-content');
    
    // Create a new text area with current post content
    var editTextarea = document.createElement('textarea');
    editTextarea.value = postContent.textContent.trim();
    editTextarea.classList.add('edit-textarea');
    
    // Replace the post content with the textarea
    postContent.innerHTML = '';
    postContent.appendChild(editTextarea);
    
    // Change button text to "Save"
    button.textContent = 'บันทึก';
    button.setAttribute('onclick', 'savePost(this)');
  }
  
  // Function to save the edited post
  function savePost(button) {
    var postDiv = button.closest('.post'); // Find the closest post div
    var editTextarea = postDiv.querySelector('.edit-textarea'); // Get the edited text area
    var postContent = postDiv.querySelector('.post-content'); // Find the post content area
    
    // Save the new content and update the UI
    postContent.innerHTML = editTextarea.value;
    
    // Change the button back to "Edit"
    button.textContent = 'แก้ไขโพสต์';
    button.setAttribute('onclick', 'editPost(this)');
  }

// Create a new post
function createPost() {
    var content = document.getElementById('post-content').value;
    var postDiv = document.createElement('div');
    postDiv.classList.add('post');
    postDiv.innerHTML = `
      <div class="post-header">
        <strong>${document.getElementById('user-name').textContent}</strong>
      </div>
      <div class="post-content">
        ${content}
      </div>
      <div class="post-footer">
        <button onclick="likePost(this)">👍 ไลค์</button>
        <span class="like-count">0</span> ไลค์
        <button onclick="editPost(this)">แก้ไขโพสต์</button> <!-- ปุ่มแก้ไขโพสต์ -->
      </div>
      <div class="comment-form">
        <textarea placeholder="คอมเม้นต์..."></textarea>
        <button onclick="addComment(this)">คอมเม้นต์</button>
      </div>
      <div class="comments-section"></div>
    `;
    document.getElementById('posts').prepend(postDiv);
    document.getElementById('post-content').value = '';  // Clear the textarea
  }

  // Function to edit a post
function editPost(button) {
    var postDiv = button.closest('.post'); // Find the closest post div
    var postContent = postDiv.querySelector('.post-content');
    
    // Create a new text area with current post content
    var editTextarea = document.createElement('textarea');
    editTextarea.value = postContent.textContent.trim();  // Set current post content as value
    postContent.innerHTML = '';  // Clear the existing post content
    
    // Append the textarea to post content
    postContent.appendChild(editTextarea);
    
    // Change button text to "Save"
    button.textContent = 'บันทึก';
    button.setAttribute('onclick', 'savePost(this)');
  }
  
  // Function to save the edited post
  function savePost(button) {
    var postDiv = button.closest('.post'); // Find the closest post div
    var editTextarea = postDiv.querySelector('textarea'); // Get the edited text area
    var postContent = postDiv.querySelector('.post-content'); // Find the post content area
    
    // Save the new content and update the UI
    postContent.textContent = editTextarea.value; // Set the new content
    
    // Change the button back to "Edit"
    button.textContent = 'แก้ไขโพสต์';
    button.setAttribute('onclick', 'editPost(this)');
  }
  